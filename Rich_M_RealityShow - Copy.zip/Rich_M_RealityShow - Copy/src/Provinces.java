
public enum Provinces {
AB,BC,MB,NB,Nl,NS,NT,NU,ON,PE,QC,SK,YT
}
